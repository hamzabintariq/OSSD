n = int(input("Enter size: "))
check = int(0)
while check < n:
    check1 = int(0)
    while check1 < n:
        if check%2==0:
            print("# ", end="")
        else:
            print(" #", end="")
        check1 += 1
    print(" ")
    check += 1