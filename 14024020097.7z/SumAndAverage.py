upperBound = int(input("Enter UpperBound: "))
sum = int(0)
check = int(0)
while check <= upperBound:
    sum = sum + check
    check  += 1
print("The sum is {}".format(sum))
average = float(sum / upperBound)
print("The average is {}".format(average))