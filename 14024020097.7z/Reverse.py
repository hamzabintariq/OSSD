n = int(input("Enter 4-digit number: "))
a = n // 1000
b = n // 100 % 10
c = n // 10 % 10
d = n % 10
print("{},{},{},{}".format(d,c,b,a))