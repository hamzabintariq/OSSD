def fib(n):
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fib(n-1) + fib(n-2)
sum = int(0)
for x in range(21):
    print(fib(x),end=" ")
    sum = sum + fib(x)
average = float(sum / 20)
print(" \nThe average is {}".format(average))