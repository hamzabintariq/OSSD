print("* | ",end="")
for x in range(1,10):
    print(x,end=" ")
print(" ")
for x in range(11):
    print("- ",end="")
print(" ")
for x in range(1,10):
    print("{} | ".format(x),end="")
    for y in range(1,10):
        print(x*y,end=" ")
    print(" ")