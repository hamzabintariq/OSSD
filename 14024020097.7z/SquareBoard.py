n = int(input("Enter size: "))
for x in range(n):
    for y in range(n):
        print("# ", end="")
    print("")