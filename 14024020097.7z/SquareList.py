L = []
n = int(input("Total size of list: "))
for i in range(n):
    x = int(input())
    L.append(x)
L1 = [a**2 for a in L]
print(L)
print(L1)
L2 = [[L[x],L1[x]] for x in range(n)]
print(L2)