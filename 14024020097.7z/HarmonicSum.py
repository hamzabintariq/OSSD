LeftHSum = 1
RightHSum = 1/50000
for x in range(2,50001):
    LeftHSum = LeftHSum + (1/x)
for x in range(50000,1,-1):
    RightHSum = RightHSum + (1/(x-1))
print("Left-to-Right: {}".format(LeftHSum))
print("Right-to-Left: {}".format(RightHSum))