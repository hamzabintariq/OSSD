number = int(input("Enter number: "))
if number % 2 == 0:
    print("Even Number")
else:
    print("Odd Number")