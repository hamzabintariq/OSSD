check = int(0)
for x in range(1,111):
    check += 1
    if x%3==0 and x%5==0:
        print("AlphaBravo",end="")
    elif x%3==0 and x%7==0:
        print("AlphaCharlie",end="")
    elif x%5==0 and x%7==0:
        print("BravoCharlie",end="")
    elif x%3==0:
        print("Alpha",end="")
    elif x%5==0:
        print("Bravo",end="")
    elif x%7==0:
        print("Charlie",end="")
    else:
        print(x,end="")
    print("\t",end="")
    if check%11==0:
        print("")