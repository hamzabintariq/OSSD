mark = int(input("Enter mark: "))
if mark >= 50:
    print("PASS")
else:
    print("FAIL")