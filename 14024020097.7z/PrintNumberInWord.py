number = int(input("Enter number: "))
if number == 1:
    print("ONE")
elif number == 2:
    print("TWO")
elif number == 3:
    print("THREE")
elif number == 4:
    print("FOUR")
elif number == 5:
    print("FIVE")
elif number == 6:
    print("SIX")
elif number == 7:
    print("SEVEN")
elif number == 8:
    print("EIGHT")
elif number == 9:
    print("NINE")
else:
    print("OTHER")